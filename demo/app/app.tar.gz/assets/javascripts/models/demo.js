var app = app || {};

(function (){
	'use strict';

	app.Demo = Backbone.Model.extend({
		defaults: {
			name: '',
			password: '',
			department: ''
		}
	});
})();