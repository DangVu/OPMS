var app = app || {};

(function () {
	'use strict';

	var Demos = Backbone.Collection.extend({
		model: app.Demo
	});
});