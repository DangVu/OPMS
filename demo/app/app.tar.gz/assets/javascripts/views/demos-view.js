// var app = app || {};

$(function (){
  	var AppView = Backbone.View.extend({
      initialize: function(){
        $("#admin").css("display", "none");
      },
      events: {
        "click .admin": "showAdmin",  
        "click .user": "showUser"
      },
      showAdmin: function( event ){
      	event.preventDefault();
      	$("#admin").css("display", "block");
      	$("#user").css("display", "none");
      },
      showUser: function( event ){
      	event.preventDefault();
      	$("#admin").css("display", "none");
      	$("#user").css("display", "block");
      }
    });

    var app_view = new AppView({ el: $(".login_main") });
});

window.onload = function() {
  document.getElementById("close_flash").addEventListener("click", function(e){
    e.preventDefault();
    var divClose = e.target.parentNode;
    divClose.parentNode.removeChild(divClose);
  });
};
  	
